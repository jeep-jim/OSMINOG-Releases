# OSMINOG 3.11.57 — Unified Module Store + Chat Memory

- Restores the in-chat bottom progress bar and removes the detached right-side runtime monitor.
- Sends current-thread history as authoritative context on every request and continuation.
- Unifies custom apps with the existing Module Store catalog.
- Removing a custom app shortcut only removes it from the desktop; the app remains in the store and can be restored.
- Keeps AI-installed apps interactive in isolated module windows and registers them immediately.

Next: permission-scoped connector SDK for OAuth modules such as Telegram shells, signed personal module sync, and subscription entitlements.
