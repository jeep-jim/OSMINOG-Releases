/* OSMINOG unified development channel: code packages are delivered by the local signed updater from the GitHub release feed. */
globalThis.BRIEFCRAFT_CLOUD_CONFIG = Object.freeze({relayHttpBase:"",relayWsBase:"",chatGPTAppUrl:"https://chatgpt.com/",devMode:true,ownerBuild:true,updateChannel:"osminog-devhub",nativeUpdaterHost:"com.briefcraft.updater"});
