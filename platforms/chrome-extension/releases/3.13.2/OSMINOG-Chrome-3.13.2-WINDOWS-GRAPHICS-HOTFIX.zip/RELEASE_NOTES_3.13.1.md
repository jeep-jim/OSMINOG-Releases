# OSMINOG Chrome 3.13.1 — ART ICONS AND READER SCROLL

- The chat opens on the latest message and changing a conversation opens that conversation on its latest message.
- Incoming AI messages and progress updates no longer force the reader to the bottom. The current manual scroll position is preserved while the answer grows.
- Sending a user message still reveals the new message, after which scrolling remains under the reader's control.
- Removes the colored rounded-square containers from the eight permanent dock applications.
- Replaces them with individual multicolor SVG artworks with highlights, depth and shadows.
- Files now uses a dimensional yellow folder matching the owner's reference.
- OSMINOG AI, Graphics, Text, Browser, Modules, Team and Development follow the same art-icon language.
- Managed application headers reuse the same artwork without adding another colored container.
