"use strict";
(()=>{
  if(globalThis.OSMINOGModuleRuntime)return;
  const GRANTS_KEY="osminogModuleGrantsV1",SECRET_PREFIX="osminogModuleSecret:",frames=new Map();
  const KNOWN=new Set(["storage","secrets","notifications","browser.open","network.fetch","canvas.read","canvas.patch","commands.run"]);
  const cleanId=v=>String(v||"").toLowerCase().replace(/[^a-z0-9._-]/g,"-").slice(0,80);
  const safeHost=value=>{try{const u=new URL(String(value||""));return /^https?:$/.test(u.protocol)?`${u.origin}/*`:""}catch{return""}};
  async function grants(){const got=await chrome.storage.local.get(GRANTS_KEY);return got[GRANTS_KEY]&&typeof got[GRANTS_KEY]==="object"?got[GRANTS_KEY]:{}}
  async function setGrants(all){await chrome.storage.local.set({[GRANTS_KEY]:all});document.dispatchEvent(new CustomEvent("osminog:module-grants-changed"))}
  async function has(moduleId,permission){const all=await grants();return all[cleanId(moduleId)]?.includes(permission)||false}
  async function request(ext,permission){if(!KNOWN.has(permission)||!ext.permissions?.includes(permission))return false;if(await has(ext.id,permission))return true;const labels={storage:"хранить настройки",secrets:"хранить секрет до закрытия браузера",notifications:"показывать уведомления","browser.open":"открывать внутренний браузер","network.fetch":"обращаться к заявленным адресам","canvas.read":"читать текущий проект","canvas.patch":"предлагать изменения холста","commands.run":"запускать команды OSMINOG"};if(!confirm(`Модуль «${ext.title}» запрашивает право: ${labels[permission]||permission}.\n\nРазрешить?`))return false;const all=await grants(),id=cleanId(ext.id),next=new Set(all[id]||[]);next.add(permission);all[id]=[...next];await setGrants(all);return true}
  async function revoke(moduleId){const all=await grants();delete all[cleanId(moduleId)];await setGrants(all);return{ok:true}}
  async function moduleStorage(ext,method,args){const key=`osminogModuleData:${cleanId(ext.id)}`,got=await chrome.storage.local.get(key),data=got[key]&&typeof got[key]==="object"?got[key]:{};if(method==="storage.get")return{value:data[String(args.key||"")]??null};if(method==="storage.set"){data[String(args.key||"").slice(0,120)]=args.value;await chrome.storage.local.set({[key]:data});return{ok:true}}return{error:"Unsupported storage operation"}}
  async function moduleSecret(ext,method,args){const key=SECRET_PREFIX+cleanId(ext.id)+":"+String(args.key||"default").slice(0,80);if(method==="secrets.get"){const got=await chrome.storage.session.get(key);return{value:got[key]||"",sessionOnly:true}}if(method==="secrets.set"){await chrome.storage.session.set({[key]:String(args.value||"")});return{ok:true,sessionOnly:true}}if(method==="secrets.remove"){await chrome.storage.session.remove(key);return{ok:true}}return{error:"Unsupported secret operation"}}
  async function invoke(ext,method,args={}){
    const permission=method.startsWith("storage.")?"storage":method.startsWith("secrets.")?"secrets":method==="notify"?"notifications":method==="browser.open"?"browser.open":method==="network.fetch"?"network.fetch":method==="canvas.status"?"canvas.read":method==="canvas.patch"?"canvas.patch":method==="commands.run"?"commands.run":"";
    if(!permission||!await request(ext,permission))return{error:`Permission denied: ${permission||method}`};
    if(method.startsWith("storage."))return moduleStorage(ext,method,args);if(method.startsWith("secrets."))return moduleSecret(ext,method,args);
    if(method==="notify"){document.dispatchEvent(new CustomEvent("osminog:module-notify",{detail:{moduleId:ext.id,title:ext.title,text:String(args.text||"").slice(0,500)}}));return{ok:true}}
    if(method==="browser.open")return chrome.runtime.sendMessage({type:"OSMINOG_BROWSER_HUB_OPEN",url:String(args.url||""),allowCreate:true});
    if(method==="canvas.status")return globalThis.BriefCraftBridge?.canvasStatus?.()||{error:"Canvas unavailable"};
    if(method==="canvas.patch")return globalThis.BriefCraftBridge?.executeTool?.("propose_canvas_patch",args)||{error:"Canvas unavailable"};
    if(method==="commands.run")return globalThis.OSMINOGCommandAPI?.run?.(args)||{error:"Commands unavailable"};
    if(method==="network.fetch"){
      const url=String(args.url||""),host=safeHost(url),allowed=(ext.hostPermissions||[]).map(safeHost).filter(Boolean);if(!host||!allowed.includes(host))return{error:"Host is not declared by the module"};const granted=await chrome.permissions.request({origins:[host]});if(!granted)return{error:"Browser host permission denied"};return chrome.runtime.sendMessage({type:"OSMINOG_MODULE_FETCH",url,options:{method:String(args.method||"GET").toUpperCase(),headers:args.headers&&typeof args.headers==="object"?args.headers:{},body:args.body==null?null:String(args.body)}})
    }
    return{error:`Unsupported module method: ${method}`}
  }
  function bridgeScript(ext){const manifest={id:ext.id,name:ext.title,version:ext.version,type:ext.type,permissions:ext.permissions||[],hostPermissions:ext.hostPermissions||[]};return`<script>(function(){const p=new Map();let n=0;window.OSMINOG={manifest:${JSON.stringify(manifest)},call:function(method,args){return new Promise(function(resolve,reject){const id='m'+(++n);p.set(id,{resolve:resolve,reject:reject});parent.postMessage({protocol:'osminog.module/v1',moduleId:${JSON.stringify(ext.id)},id:id,method:method,args:args||{}},'*');setTimeout(function(){if(p.has(id)){p.delete(id);reject(new Error('OSMINOG module request timed out'))}},30000)})}};addEventListener('message',function(e){const d=e.data||{},x=p.get(d.id);if(d.protocol!=='osminog.module-result/v1'||!x)return;p.delete(d.id);d.error?x.reject(new Error(d.error)):x.resolve(d.result)});parent.postMessage({protocol:'osminog.module-ready/v1',moduleId:${JSON.stringify(ext.id)}},'*')})();<\/script>`}
  function inject(ext,html){const script=bridgeScript(ext);return /<head[^>]*>/i.test(html)?html.replace(/<head[^>]*>/i,m=>m+script):script+html}
  function bindFrame(ext,frame){frames.set(frame.contentWindow,{ext,frame})}
  function mount(ext,frame){frame.src=chrome.runtime.getURL("module-frame.html");frame.addEventListener("load",()=>{bindFrame(ext,frame);frame.contentWindow.postMessage({protocol:"osminog.module-init/v1",html:inject(ext,ext.html)},"*")},{once:true})}
  addEventListener("message",async event=>{const d=event.data||{},bound=frames.get(event.source);if(!bound||d.protocol!=="osminog.module/v1"||d.moduleId!==bound.ext.id)return;let result;try{result=await invoke(bound.ext,String(d.method||""),d.args||{})}catch(e){result={error:e?.message||String(e)}}event.source.postMessage({protocol:"osminog.module-result/v1",id:d.id,result:result?.error?null:result,error:result?.error||""},"*")});
  globalThis.OSMINOGModuleRuntime={knownPermissions:[...KNOWN],inject,bindFrame,mount,invoke,grants,has,revoke};
})();
