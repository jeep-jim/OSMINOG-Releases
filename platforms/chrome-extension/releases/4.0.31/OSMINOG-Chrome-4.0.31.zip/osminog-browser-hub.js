"use strict";
(() => {
 const $=s=>document.querySelector(s),send=(type,extra={})=>chrome.runtime.sendMessage({type,...extra});
 for(const id of ["browserHub","browserHubButton","osminogWebWorkspace","owDeskDivider"])document.getElementById(id)?.remove();
 async function connections(){await globalThis.BriefCraftBridge?.open?.();globalThis.OSMINOGSetAgentSettingsOpen?.(true);return {ok: true, mode: 'chat-settings', popup: false};}
 let app=null,divider=null,globe=null,monitor=null,mode="desk",ratio=.5,raf=0,drag=null;
 const projectId=()=>String(globalThis.project?.()?.id||""),ru=()=>typeof state==="undefined"||state.language==="ru",label=(r,e)=>ru()?r:e;
 const getApp=()=>globalThis.OSMINOGBrowserApp;
 function setMode(next){mode=next;document.body.dataset.webWorkspace=next;scheduleLayout();globe?.setAttribute("aria-pressed",String(next!=="desk"));monitor?.setAttribute("aria-pressed",String(next==="split"))}
 function dockApp(){
  app=document.getElementById("osminogBrowserApp");if(!app)return;
  const chat=$("#bridgePanel"),chatOpen=!!chat&&!chat.hidden,right=chatOpen?chat.getBoundingClientRect().left-7:innerWidth,available=Math.max(0,right),top=$("#app .topbar")?.getBoundingClientRect().bottom||56,split=mode==="split"&&available>=600,cut=split?Math.round(Math.max(260,Math.min(available-260,available*ratio))):0,left=split?cut+7:0,width=Math.max(0,available-left);
  Object.assign(app.style,{position:"fixed",left:left+"px",top:top+"px",right:"auto",bottom:"0",width:width+"px",height:"auto",maxWidth:"none",maxHeight:"none",margin:"0",transform:"none"});
  for(const [k,v] of Object.entries({left:left+"px",top:top+"px",right:"auto",bottom:"0",width:width+"px",height:"auto","z-index":"110"}))app.style.setProperty(k,v,"important");
  app.dataset.osminogDocked="1";if(divider){divider.hidden=!split;divider.style.left=cut+"px";divider.setAttribute("aria-valuenow",String(Math.round(ratio*100)))}document.documentElement.style.setProperty("--ow-cut",cut+"px");globalThis.applyView?.();
 }
 function scheduleLayout(){if(!raf)raf=requestAnimationFrame(()=>{raf=0;dockApp()})}
 function open(url,opts={}){const browser=getApp();if(!browser?.open)return{ok:false,error:"Штатный браузер OSMINOG не загружен"};const opened=browser.open(url||"",opts);app=opened||document.getElementById("osminogBrowserApp");setMode(mode==="split"?"split":"browser");scheduleLayout();requestAnimationFrame(scheduleLayout);return{ok:true,mode:"browser-app-window",url:String(url||""),projectId:projectId(),displayVerified:false,note:"Открыто штатное окно Browser App. Сайты, запрещающие iframe, используют управляемую вкладку Chrome."}}
 function button(id,path,title,click){const el=document.createElement("button");el.type="button";el.id=id;el.className="icon-btn ow-header-button";el.title=title;el.setAttribute("aria-label",title);el.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true">'+path+"</svg>";el.onclick=click;return el}
 function install(){
  const link=document.createElement("link");link.rel="stylesheet";link.href="osminog-browser-workspace.css";document.head.append(link);
  globe=button("workspaceWebToggle",'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z"/>',label("Браузер","Browser"),()=>{if(mode!=="desk"){setMode("desk");return}const tabs=getApp()?.listTabs?.()||[];if(tabs.length){getApp()?.open?.(tabs.at(-1).url);setMode("browser")}else open("")});
  monitor=button("workspaceDeskToggle",'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8m-4-4v4"/>',label("Стол и браузер рядом","Desk and browser side by side"),()=>{if(mode==="split")setMode("browser");else if(mode==="browser")setMode("split");else{const tabs=getApp()?.listTabs?.()||[];if(tabs.length){getApp()?.open?.(tabs.at(-1).url);setMode("split")}}});
  $("#app .top-actions")?.prepend(globe,monitor);
  divider=document.createElement("div");divider.id="owDeskDivider";divider.hidden=true;divider.tabIndex=0;divider.role="separator";divider.setAttribute("aria-orientation","vertical");divider.setAttribute("aria-label",label("Ширина стола и браузера","Desk and browser width"));divider.setAttribute("aria-valuemin","20");divider.setAttribute("aria-valuemax","80");$("#app").append(divider);
  divider.onpointerdown=e=>{if(e.button!==0)return;drag=e.pointerId;divider.setPointerCapture(e.pointerId);document.body.classList.add("ow-resizing");e.preventDefault()};
  divider.onpointermove=e=>{if(drag!==e.pointerId)return;const chat=$("#bridgePanel"),available=chat&&!chat.hidden?chat.getBoundingClientRect().left-7:innerWidth;ratio=Math.max(.2,Math.min(.8,e.clientX/Math.max(1,available)));scheduleLayout()};
  const finish=()=>{if(drag===null)return;drag=null;document.body.classList.remove("ow-resizing")};divider.onpointerup=finish;divider.onpointercancel=finish;divider.onlostpointercapture=finish;
  divider.onkeydown=e=>{if(!["ArrowLeft","ArrowRight","Home"].includes(e.key))return;e.preventDefault();ratio=e.key==="Home"?.5:Math.max(.2,Math.min(.8,ratio+(e.key==="ArrowLeft"?-.03:.03)));scheduleLayout()};divider.ondblclick=()=>{ratio=.5;scheduleLayout()};
  const ro=new ResizeObserver(scheduleLayout);for(const el of [$("#app .topbar"),$("#bridgePanel")])if(el)ro.observe(el);if($("#bridgePanel"))new MutationObserver(scheduleLayout).observe($("#bridgePanel"),{attributes:true,attributeFilter:["hidden"]});window.addEventListener("resize",scheduleLayout,{passive:true});
  document.addEventListener("osminog:project-opened",scheduleLayout);
  globalThis.OSMINOGBrowserHubAPI={open:connections,close:()=>setMode("desk"),refresh:async()=>({ok:true}),list:()=>send("OSMINOG_SESSION_LIST"),openUrl:(url,provider="")=>provider&&provider!=="web"?connections():open(url)};
  globalThis.OSMINOGOpenConnections=connections;globalThis.OSMINOGWebWorkspace={open,close:()=>setMode("desk"),split:()=>setMode("split"),list:()=>getApp()?.listTabs?.()||[]};
  const previous=globalThis.OSMINOGWorkspaceTools,names=["browser_open","browser_tabs","browser_context","browser_close","browser_read","browser_act"];
  globalThis.OSMINOGWorkspaceTools={names:[...new Set([...(previous?.names||[]),...names])],async run(name,args={}){if(!names.includes(name))return previous.run(name,args);if(name==="browser_open")return open(args.url,{provider:args.provider||"",newTab:args.newTab!==false});if(name==="browser_tabs")return{ok:true,projectId:projectId(),tabs:getApp()?.listTabs?.()||[]};if(name==="browser_context"||name==="browser_read")return getApp()?.context?.()||{ok:false,error:"Нет активной страницы"};if(name==="browser_act")return getApp()?.applyEdit?.(args)||{ok:false,error:"Нет выбранного элемента страницы"};if(name==="browser_close"){const id=String(args.tabId||args.id||"");getApp()?.closeTab?.(id);scheduleLayout();return{ok:true,closed:true,id}}}};
  scheduleLayout();
 }
 const ready=new Promise(resolve=>{const run=()=>{install();resolve()};if(document.readyState==="loading")document.addEventListener("DOMContentLoaded",run,{once:true});else run()});
 globalThis.OSMINOGBrowserHubReady=ready;globalThis.OSMINOGBrowserHubAPI||={open:connections,close(){}};
})();