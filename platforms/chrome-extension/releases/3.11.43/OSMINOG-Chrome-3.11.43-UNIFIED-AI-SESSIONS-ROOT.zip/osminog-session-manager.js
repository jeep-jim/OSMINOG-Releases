"use strict";
(()=>{
  if(globalThis.OSMINOGSessionManager)return;
  const $=(s,r=document)=>r.querySelector(s);
  const normalize=id=>{id=String(id||"").toLowerCase();return id==="chatgpt"?"gpt":id==="google-ai"?"googleai":id};
  const registryId=id=>normalize(id)==="gpt"?"chatgpt":normalize(id);
  const custom={id:"custom",name:"Custom AI",category:"chat",icon:"AI",iconSrc:"icons/providers/custom.svg",tone:"#8b5cf6",access:"OpenAI-compatible",caps:["локально","API","код"]};
  const esc=s=>String(s??"").replace(/[&<>\"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
  function providers(){return globalThis.OSMINOGProviderRegistry?.list?.()||[]}
  function brainProviders(){const list=providers().map(p=>({...p,brainId:p.id==="chatgpt"?"gpt":p.id}));return [...list,custom].filter((p,i,a)=>a.findIndex(x=>(x.brainId||x.id)===(p.brainId||p.id))===i)}
  function brainIds(){return brainProviders().map(p=>p.brainId||p.id)}
  function meta(id){id=normalize(id);if(id==="custom")return custom;return providers().find(p=>p.id===registryId(id)||p.id===id||normalize(p.bridge||p.id)===id)||null}
  function label(id){return meta(id)?.name||(normalize(id)==="gpt"?"ChatGPT":String(id||"AI"))}
  async function call(type,extra={}){return chrome.runtime.sendMessage({type,...extra})}
  async function list(){return call("OSMINOG_SESSION_LIST").catch(e=>({ok:false,error:e?.message||String(e),tabs:[],sessions:{}}))}
  function emit(id,detail={}){document.dispatchEvent(new CustomEvent("osminog:session-changed",{detail:{provider:normalize(id),...detail}}))}

  async function getOrCreate(id,opts={}){
    id=normalize(id);const p=meta(id),provider=id==="gpt"?"gpt":(p?.id||id),url=opts.url||p?.url||"";
    const r=await call("OSMINOG_SESSION_GET_OR_CREATE",{provider,url,active:!!opts.active,reuse:opts.reuse!==false,allowCreate:opts.allowCreate===true});
    if(r?.ok)emit(id,{session:r});
    return r
  }
  async function connect(id){
    id=normalize(id);
    if(id==="gpt"){const btn=$("#gptPresenceConnect");if(btn){btn.click();return{ok:true,pending:true,provider:id,mode:"direct-session"}}return{ok:false,error:"ChatGPT panel not ready"}}
    if(id==="custom")return{ok:true,provider:id,mode:"custom"};
    const r=await call("OSMINOG_SESSION_CONNECT_EXISTING",{provider:id});
    if(r?.ok){emit(id,{connected:true,session:r});await refreshCenter(id)}
    return r
  }
  async function authorize(id){
    id=normalize(id);
    if(id==="gpt")return{ok:true,provider:id,mode:"direct-session",note:"ChatGPT использует текущую авторизованную сессию"};
    if(id==="custom")return{ok:true,provider:id,mode:"custom"};
    const r=await call("OSMINOG_SESSION_AUTHORIZE",{provider:id});
    if(r?.ok)emit(id,{authorization:true,session:r});
    return r
  }
  async function status(id){
    id=normalize(id);
    if(id==="gpt")return{ok:true,provider:id,connected:false,mode:"direct-session"};
    if(id==="custom"){const r=await call("BC_PROVIDER_CUSTOM_GET").catch(()=>null);return{ok:true,provider:id,connected:!!(r?.config?.baseUrl&&r?.config?.model),mode:"custom",config:r?.config||{}}}
    const linked=await call("BC_PROVIDER_DISCOVER",{provider:id}).catch(()=>null);
    if(linked?.connected)return{ok:true,provider:id,connected:true,mode:linked.linked?.directWeb?"direct-web-session":"attached-tab",tabId:linked.linked?.tabId,title:linked.linked?.title};
    return{ok:true,provider:id,connected:false,found:linked?.found||null,mode:linked?.found?"open-tab":"none",tabId:linked?.found?.tabId||null,title:linked?.found?.title||meta(id)?.name||id}
  }
  async function focus(id){const st=await status(id);if(st?.tabId)return call("OSMINOG_BROWSER_HUB_FOCUS_TAB",{tabId:st.tabId});return authorize(id)}

  function icon(p){return p?.iconSrc?`<img src="${esc(p.iconSrc)}" alt="${esc(p.name||"AI")}" referrerpolicy="no-referrer"><b hidden>${esc(p?.icon||"AI")}</b>`:`<b>${esc(p?.icon||"AI")}</b>`}
  function activeProvider(){return normalize($("#gptAgentProvider")?.value||"gpt")}
  async function openSettings(id=""){
    try{await globalThis.OSMINOGOpenUnifiedChat?.()}catch{}
    const panel=$("#bridgePanel");if(panel)panel.hidden=false;const bubble=$("#gptPresenceBubble");if(bubble)bubble.hidden=true;
    const settings=$("#gptPresenceSettingsPanel");if(settings?.hidden)$("#gptPresenceSettingsToggle")?.click();
    if(id){const sel=$("#gptAgentProvider");if(sel&&sel.value!==normalize(id)){sel.value=normalize(id);sel.dispatchEvent(new Event("change",{bubbles:true}))}}
    setTimeout(()=>$("#gptProviderConnectRow")?.scrollIntoView?.({block:"center",behavior:"smooth"}),80)
  }
  function showReconnect(id,reason="closed"){
    id=normalize(id);const previous=$("#osminogSessionReconnectToast");if(previous?.dataset.provider===id)return;previous?.remove();
    const p=meta(id)||{name:label(id),icon:"AI"},toast=document.createElement("aside");toast.id="osminogSessionReconnectToast";toast.className="osminog-session-reconnect";toast.dataset.provider=id;toast.setAttribute("role","alert");toast.innerHTML=`<span class="osminog-session-reconnect-icon">${icon(p)}</span><div><strong>${esc(label(id))} отключён</strong><small>${reason==="navigated"?"Вкладка ушла с сайта сервиса.":"Связанная вкладка закрыта."}</small></div><button type="button" data-session-reconnect>Подключить ${esc(label(id))}</button><button type="button" data-session-dismiss aria-label="Закрыть">×</button>`;
    document.body.append(toast);
    toast.querySelector("[data-session-dismiss]")?.addEventListener("click",()=>toast.remove());
    toast.querySelector("[data-session-reconnect]")?.addEventListener("click",async e=>{e.currentTarget.disabled=true;const r=await connect(id).catch(error=>({ok:false,error:error?.message||String(error)}));if(r?.ok)toast.remove();else{e.currentTarget.disabled=false;await openSettings(id)}});
    setTimeout(()=>{if(toast.isConnected)toast.classList.add("visible")},20)
  }
  async function refreshCenter(selected=activeProvider()){
    const box=$("#osminogSessionConnectedList");if(!box)return;
    const r=await list(),items=Object.entries(r?.sessions||{});
    box.innerHTML=items.length?items.map(([id])=>`<button type="button" data-session-provider="${esc(id)}" title="Показать связанную вкладку"><i></i><span>${esc(label(id))}</span><small>On</small></button>`).join(""):`<span class="osminog-session-empty">Нет подключённых web-сессий</span>`;
    box.querySelectorAll("[data-session-provider]").forEach(b=>b.addEventListener("click",()=>focus(b.dataset.sessionProvider)));
    const st=await status(selected),row=$("#gptProviderConnectRow");if(row)row.classList.toggle("connected",!!st?.connected)
  }
  function bindSessionActions(row){
    for(const [selector,kind] of [["#gptProviderTabConnect","connect"],["#gptProviderAuthorize","authorize"]]){
      const old=$(selector,row);if(!old||old.dataset.sessionRouter==="1")continue;
      const button=old.cloneNode(true);button.dataset.sessionRouter="1";old.replaceWith(button);
      button.addEventListener("click",async()=>{const id=activeProvider();button.disabled=true;const state=$("#gptProviderTabState");try{if(kind==="connect"){if(state)state.textContent=`Ищу открытую вкладку ${label(id)}…`;const r=await connect(id);if(!r?.ok){if(state)state.textContent=r?.needsOpenTab?`${label(id)} не открыт. Нажми «Открыть для входа», затем вернись и подключи вкладку.`:(r?.error||"Не удалось подключить");return}if(state)state.textContent=`${label(id)} подключён. Чат остаётся внутри OSMINOG.`}else{const r=await authorize(id);if(!r?.ok){if(state)state.textContent=r?.error||"Не удалось открыть сервис";return}if(state)state.textContent=r.reusedExisting?`${label(id)} уже открыт — вкладка показана.`:`${label(id)} открыт для входа. После авторизации вернись сюда и подключи вкладку.`}}finally{button.disabled=false;emit(id,{refresh:true});refreshCenter(id)}})
    }
  }
  function installAgentSettings(){
    const panel=$("#gptPresenceSettingsPanel"),sel=$("#gptAgentProvider");if(!panel||!sel)return false;
    const brains=brainProviders();sel.innerHTML=brains.map(p=>`<option value="${esc(p.brainId||p.id)}">${esc(p.name)}</option>`).join("");
    $("#gptProviderBrandGrid")?.remove();$("#osminogBrainPicker")?.remove();$("#osminogSettingsProviderTools")?.remove();
    const providerLabel=sel.closest("label");providerLabel?.classList.add("gpt-native-provider-select");
    const picker=document.createElement("div");picker.id="osminogBrainPicker";picker.className="osminog-brain-picker";picker.innerHTML=`<div class="osminog-brain-picker-head"><span>МОЗГ АГЕНТА</span><small>Выбери ИИ для этого чата. OSMINOG подключает уже открытую авторизованную вкладку, а сам диалог остаётся здесь.</small></div><div class="osminog-brain-picker-grid">${brains.map(p=>`<button type="button" data-brain="${esc(p.brainId||p.id)}" title="${esc(p.name)}" style="--provider-tone:${esc(p.tone||"#58c9ff")}">${icon(p)}<span>${esc(p.name)}</span><i></i></button>`).join("")}</div>`;providerLabel?.before(picker);
    picker.querySelectorAll("img").forEach(img=>img.addEventListener("error",()=>{img.hidden=true;if(img.nextElementSibling)img.nextElementSibling.hidden=false},{once:true}));
    function syncBrain(){picker.querySelectorAll("[data-brain]").forEach(b=>b.classList.toggle("active",b.dataset.brain===sel.value))}
    picker.querySelectorAll("[data-brain]").forEach(b=>b.addEventListener("click",()=>{sel.value=b.dataset.brain;sel.dispatchEvent(new Event("change",{bubbles:true}));syncBrain()}));sel.addEventListener("change",()=>{syncBrain();refreshCenter(sel.value)});syncBrain();
    const row=$("#gptProviderConnectRow");if(row){row.classList.add("osminog-session-center");if(!$("#osminogSessionCenterHead",row)){const head=document.createElement("div");head.id="osminogSessionCenterHead";head.className="osminog-session-center-head";head.innerHTML='<div><b>ПОДКЛЮЧЕНИЯ ИИ</b><small>Без скрытого автозапуска</small></div><span>Chat stays inside OSMINOG</span>';row.prepend(head)}if(!$("#osminogSessionConnectedList",row)){const connected=document.createElement("div");connected.id="osminogSessionConnectedList";connected.className="osminog-session-connected-list";row.append(connected)}const connectBtn=$("#gptProviderTabConnect",row),authBtn=$("#gptProviderAuthorize",row);if(connectBtn)connectBtn.textContent="Подключить открытую вкладку";if(authBtn)authBtn.textContent="Открыть для входа";bindSessionActions(row)}
    $("#bridgeLiveBadge")?.setAttribute("aria-label","Provider status");refreshCenter(sel.value);return true
  }
  let tries=0;const timer=setInterval(()=>{tries++;if(installAgentSettings()||tries>40)clearInterval(timer)},120);
  chrome.runtime.onMessage.addListener(message=>{if(message?.type!=="OSMINOG_SESSION_DISCONNECTED")return;showReconnect(message.provider,message.reason);emit(message.provider,{connected:false,reason:message.reason});refreshCenter(message.provider)});
  document.addEventListener("osminog:session-changed",e=>refreshCenter(e.detail?.provider||activeProvider()));
  globalThis.OSMINOGSessionManager={version:"3.11.43",list,getOrCreate,connect,authorize,status,focus,providers,meta,brainProviders,brainIds:brainIds(),openSettings,showReconnect,refreshCenter};
  globalThis.OSMINOGOpenProviderSettings=openSettings;
  $("#browserHubButton")?.addEventListener("click",()=>openSettings());
  document.dispatchEvent(new CustomEvent("osminog:session-manager-ready"));
})();
