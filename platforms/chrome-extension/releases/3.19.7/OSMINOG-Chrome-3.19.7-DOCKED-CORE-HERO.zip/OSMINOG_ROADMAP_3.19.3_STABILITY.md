# OSMINOG 3.19.3 — Stability / Native Drop

- Tools moved to compact bottom dock.
- Layers moved to left, properties stay right.
- Left and right panels have draggable splitters.
- ResizeObserver/render loop guarded to stop freezes.
- Native drag & drop of arbitrary PC files to main canvas restored.
