# Third-party notices

## Fabric.js
OSMINOG bundles Fabric.js for local 2D graphics. See `vendor/FABRIC_LICENSE.txt`.

## Inkscape / GIMP references
No source from Inkscape or GIMP is embedded in this build. Their UI/tool concepts were reviewed as product references only. Inkscape complete binaries are GPL-3.0-or-later; GIMP's repository COPYING is GNU GPL v3.
