# OSMINOG 3.19.5 — Split Core Hero

- Approved human is a separate transparent layer on the left of the empty-state card.
- Approved red octopus + AI logos are a separate transparent layer above/right of the card.
- No banana/stars or combined 3.19.4 hero layer.
- Hero layers use pointer-events:none and responsive placement.
- Native file drop uses one guarded viewport path; the duplicate 3.19.3 capture-level handler and fullscreen overlay are removed.
- Runtime UI verification remains manual after update.
