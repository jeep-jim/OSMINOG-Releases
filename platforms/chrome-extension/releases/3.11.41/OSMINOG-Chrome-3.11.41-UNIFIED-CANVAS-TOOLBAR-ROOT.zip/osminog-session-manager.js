"use strict";
(()=>{
  if(globalThis.OSMINOGSessionManager)return;
  const $=(s,r=document)=>r.querySelector(s);
  const normalize=id=>{id=String(id||"").toLowerCase();return id==="chatgpt"?"gpt":id==="google-ai"?"googleai":id};
  const registryId=id=>normalize(id)==="gpt"?"chatgpt":normalize(id);
  const custom={id:"custom",name:"Custom AI",category:"chat",icon:"AI",iconSrc:"icons/providers/custom.svg",tone:"#8b5cf6",access:"OpenAI-compatible",caps:["локально","API","код"]};
  function providers(){return globalThis.OSMINOGProviderRegistry?.list?.()||[]}
  function brainProviders(){const list=providers().map(p=>({...p,brainId:p.id==="chatgpt"?"gpt":p.id}));return [...list,custom].filter((p,i,a)=>a.findIndex(x=>(x.brainId||x.id)===(p.brainId||p.id))===i)}
  function brainIds(){return brainProviders().map(p=>p.brainId||p.id)}
  function meta(id){id=normalize(id);if(id==="custom")return custom;return providers().find(p=>p.id===registryId(id)||p.id===id||normalize(p.bridge||p.id)===id)||null}
  async function call(type,extra={}){return chrome.runtime.sendMessage({type,...extra})}
  async function list(){return call("OSMINOG_SESSION_LIST").catch(e=>({ok:false,error:e?.message||String(e),tabs:[],sessions:{}}))}
  async function getOrCreate(id,opts={}){id=normalize(id);const p=meta(id),provider=id==="gpt"?"gpt":(p?.id||id),url=opts.url||p?.url||"";const r=await call("OSMINOG_SESSION_GET_OR_CREATE",{provider,url,active:!!opts.active,reuse:opts.reuse!==false});if(r?.ok)document.dispatchEvent(new CustomEvent("osminog:session-changed",{detail:{provider:id,session:r}}));return r}
  async function connect(id){id=normalize(id);if(id==="gpt"){const btn=$("#gptPresenceConnect");if(btn){btn.click();return{ok:true,pending:true,provider:id,mode:"direct-session"}}return{ok:false,error:"ChatGPT panel not ready"}}
    if(id==="custom")return{ok:true,provider:id,mode:"custom"};
    const created=await getOrCreate(id,{active:false,reuse:true});if(!created?.ok)return created;
    if(id==="googleai"){const r=await call("BC_GOOGLE_AI_SERVICE_CONNECT");if(r?.ok)document.dispatchEvent(new CustomEvent("osminog:session-changed",{detail:{provider:id,connected:true}}));return r}
    const r=await call("OSMINOG_SESSION_CONNECT",{provider:id,tabId:created.tabId});if(r?.ok)document.dispatchEvent(new CustomEvent("osminog:session-changed",{detail:{provider:id,connected:true,session:r}}));return r
  }
  async function authorize(id){id=normalize(id);if(id==="gpt")return{ok:true,provider:id,mode:"direct-session",note:"ChatGPT использует текущую авторизованную сессию"};const st=await status(id);if(st?.tabId){await call("OSMINOG_BROWSER_HUB_FOCUS_TAB",{tabId:st.tabId}).catch(()=>null);const hub=await list();const winId=hub?.sessions?.[registryId(id)]?.windowId||hub?.sessions?.[id]?.windowId;if(winId)await chrome.windows.update(winId,{state:"normal",focused:true}).catch(()=>{});return{ok:true,provider:id,tabId:st.tabId,mode:"authorize"}}return getOrCreate(id,{active:true,reuse:true})}
  async function status(id){id=normalize(id);if(id==="gpt")return{ok:true,provider:id,connected:false,mode:"direct-session"};if(id==="googleai"){const r=await call("BC_GOOGLE_AI_SERVICE_STATUS").catch(()=>null);if(r?.connected)return{ok:true,provider:id,connected:true,mode:"service",tabId:r.tabId,title:r.title}}
    if(id==="custom"){const r=await call("BC_PROVIDER_CUSTOM_GET").catch(()=>null);return{ok:true,provider:id,connected:!!(r?.config?.baseUrl&&r?.config?.model),mode:"custom",config:r?.config||{}}}
    const linked=await call("BC_PROVIDER_DISCOVER",{provider:id}).catch(()=>null);if(linked?.connected)return{ok:true,provider:id,connected:true,mode:linked.linked?.directWeb?"direct-web-session":"bridge",tabId:linked.linked?.tabId,title:linked.linked?.title};
    const hub=await list(),rid=registryId(id),session=hub?.sessions?.[rid]||hub?.sessions?.[id],tab=session?.tabId?(hub.tabs||[]).find(t=>Number(t.id)===Number(session.tabId)):null;return{ok:true,provider:id,connected:false,sessionReady:!!session,mode:session?"browser":"none",tabId:session?.tabId||null,title:tab?.title||meta(id)?.name||id}
  }
  async function focus(id){const st=await status(id);if(st?.tabId)return call("OSMINOG_BROWSER_HUB_FOCUS_TAB",{tabId:st.tabId});return getOrCreate(id,{active:true})}

  function icon(p){return p?.iconSrc?`<img src="${p.iconSrc}" alt="${String(p.name||'AI').replace(/"/g,'&quot;')}" referrerpolicy="no-referrer"><b hidden>${p?.icon||"AI"}</b>`:`<b>${p?.icon||"AI"}</b>`}
  function installAgentSettings(){const panel=$("#gptPresenceSettingsPanel"),sel=$("#gptAgentProvider");if(!panel||!sel)return false;
    const brains=brainProviders();sel.innerHTML=brains.map(p=>`<option value="${p.brainId||p.id}">${p.name}</option>`).join("");
    const oldBrand=$("#gptProviderBrandGrid");oldBrand?.remove();const oldBrain=$("#osminogBrainPicker");oldBrain?.remove();const oldTools=$("#osminogSettingsProviderTools");oldTools?.remove();
    const label=sel.closest("label");if(label)label.classList.add("gpt-native-provider-select");
    const picker=document.createElement("div");picker.id="osminogBrainPicker";picker.className="osminog-brain-picker";picker.innerHTML=`<div class="osminog-brain-picker-head"><span>МОЗГ АГЕНТА</span><small>Любой подключаемый сервис может быть отдельным агентом. Для сайтов без специального transport OSMINOG использует generic web-session bridge.</small></div><div class="osminog-brain-picker-grid">${brains.map(p=>`<button type="button" data-brain="${p.brainId||p.id}" title="${p.name}" style="--provider-tone:${p.tone||'#58c9ff'}">${icon(p)}<span>${p.name}</span><i></i></button>`).join("")}</div>`;label?.before(picker);
    function bindFallbacks(root){root?.querySelectorAll?.("img").forEach(img=>img.addEventListener("error",()=>{img.hidden=true;if(img.nextElementSibling)img.nextElementSibling.hidden=false},{once:true}))}bindFallbacks(picker);
    function syncBrain(){picker.querySelectorAll("[data-brain]").forEach(b=>b.classList.toggle("active",b.dataset.brain===sel.value))}
    picker.querySelectorAll("[data-brain]").forEach(b=>b.addEventListener("click",()=>{sel.value=b.dataset.brain;sel.dispatchEvent(new Event("change",{bubbles:true}));syncBrain()}));sel.addEventListener("change",syncBrain);syncBrain();return true
  }
  function installStatusStyling(){const badge=$("#bridgeLiveBadge");if(badge)badge.setAttribute("aria-label","Provider status")}
  let tries=0;const timer=setInterval(()=>{tries++;const ok=installAgentSettings();installStatusStyling();if(ok||tries>40)clearInterval(timer)},120);
  globalThis.OSMINOGSessionManager={version:"3.11.27",list,getOrCreate,connect,authorize,status,focus,providers,meta,brainProviders,brainIds:brainIds()};
  document.dispatchEvent(new CustomEvent("osminog:session-manager-ready"));
})();
