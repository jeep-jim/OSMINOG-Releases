# Third-party notices

## Fabric.js
OSMINOG bundles Fabric.js for local 2D graphics. See `vendor/FABRIC_LICENSE.txt`.

## Inkscape / GIMP references
No source from Inkscape or GIMP is embedded in this build. Their UI/tool concepts were reviewed as product references only. Inkscape complete binaries are GPL-3.0-or-later; GIMP's repository COPYING is GNU GPL v3.


PDF document editor (3.20.4): pdf-lib 1.17.1 (MIT), @pdf-lib/fontkit 1.1.1 (MIT), Mozilla PDF.js 4.10.38 (Apache-2.0), DejaVu Sans font (see vendor/pdf/DEJAVU_LICENSE). Bundled files load locally, without a runtime CDN. Notices and license files are in vendor/pdf/.
